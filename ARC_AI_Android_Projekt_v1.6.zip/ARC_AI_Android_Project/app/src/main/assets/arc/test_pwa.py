import json, unittest
from pathlib import Path
ROOT=Path(__file__).parent
HTML=(ROOT/'index.html').read_text(encoding='utf-8')
class PWATests(unittest.TestCase):
 def test_manifest_is_valid_and_standalone(self):
  m=json.loads((ROOT/'manifest.webmanifest').read_text())
  self.assertEqual(m['display'],'standalone')
  self.assertTrue(any(i['sizes']=='192x192' for i in m['icons']))
 def test_service_worker_caches_app_shell(self):
  sw=(ROOT/'service-worker.js').read_text()
  self.assertIn('caches.open(CACHE_NAME)',sw); self.assertIn("'./index.html'",sw)
 def test_install_ui_and_registration(self):
  self.assertIn('id="installApp"',HTML); self.assertIn("navigator.serviceWorker.register('./service-worker.js')",HTML)
 def test_live_navigation_features(self):
  for term in ('renderNavigationMap','updateLiveNavigation','turnInstruction','navDeviation','möglicherweise mehr als 60 m'):
   self.assertIn(term,HTML)
 def test_no_external_script_dependency(self):
  self.assertNotRegex(HTML,r'<script[^>]+src=')
 def test_financial_rule_remains(self):
  self.assertIn('Ich darf niemals etwas kaufen oder bestellen',HTML)
if __name__=='__main__': unittest.main(verbosity=2)
