import unittest
from pathlib import Path
HTML=(Path(__file__).parent/'index.html').read_text(encoding='utf-8')
class ProfileNutritionTests(unittest.TestCase):
 def test_profile_has_body_metrics(self):
  for x in ('id="profileAge"','id="profileHeight"','id="profileWeight"','id="profileSex"','id="profileActivity"','id="profileNutritionGoal"'): self.assertIn(x,HTML)
 def test_meal_photo_and_transparency(self):
  for x in ('id="mealPhoto"','id="mealDescription"','id="mealPreview"','keine Bild-KI','wird nicht hochgeladen'): self.assertIn(x,HTML)
 def test_bmi_not_used_and_optional_measurements_exist(self):
  self.assertIn('id="waist"', HTML)
  self.assertIn('id="hip"', HTML)
  self.assertIn('verwendet keinen BMI als Entscheidungsgrundlage', HTML)
  self.assertNotIn('BMI berechnet', HTML)
 def test_targets_calculation(self):
  for x in ('function calculateNutritionTargets','Formel-Schätzung','Unter 18','id="calculateTargets"'): self.assertIn(x,HTML)
 def test_no_external_scripts(self): self.assertNotRegex(HTML,r'<script[^>]+src=')
if __name__=='__main__': unittest.main(verbosity=2)
