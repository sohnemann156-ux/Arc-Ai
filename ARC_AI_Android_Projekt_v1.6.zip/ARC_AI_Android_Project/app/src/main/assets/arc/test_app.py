import unittest
from pathlib import Path
import re
ROOT=Path(__file__).parent
HTML=(ROOT/'index.html').read_text(encoding='utf-8')
class AppSmokeTests(unittest.TestCase):
 def test_primary_sections_and_jogging_tab(self):
  for section in ('dashboard','nutrition','training','jogging','assistant','settings'): self.assertIn(f'id="{section}"',HTML)
 def test_route_inputs_and_scenery_preferences(self):
  for token in ('runTime','runDifficulty','runStart','value="park"','value="forest"','value="water"','routeConsent','buildRoute'): self.assertIn(token,HTML)
 def test_explicit_consent_precedes_external_route_calls(self):
  self.assertIn('Bitte bestätige zuerst die Übermittlung',HTML)
  self.assertIn('openstreetmap.org/search',HTML.lower())
  self.assertIn('routing.openstreetmap.de/routed-foot/trip',HTML)
 def test_route_saving_uses_workout_log(self): self.assertIn("type:'Laufen · '",HTML)
 def test_no_payment_capability_in_route_feature(self):
  route=HTML[HTML.find('// Lauf-Routenplaner'):HTML.find('// Navigation')]
  self.assertNotRegex(route.lower(),r'checkout|payment|purchase|subscribe|zahlung auslösen')
 def test_financial_safety_rule_remains(self):
  self.assertIn('Ich darf niemals etwas kaufen oder bestellen',HTML)
 def test_no_external_scripts_or_map_sdk(self): self.assertNotRegex(HTML,r'<script[^>]+src=')
 def test_local_storage_and_backup_remain(self):
  self.assertIn('localStorage.setItem(KEY',HTML); self.assertIn('arc-ai-backup.json',HTML)
 def test_optional_gps_tracking_controls_exist(self):
  for token in ('trackConsent','startTracking','finishTracking','navigator.geolocation.watchPosition','distanceMeters'):
   self.assertIn(token,HTML)
 def test_run_history_and_profile_are_persisted(self):
  for token in ('runLevel','runTotalCount','runTotalKm','runHistory','state.runs.push(rec)','state.settings.runLevel'):
   self.assertIn(token,HTML)
 def test_tracking_is_opt_in_and_local(self):
  self.assertIn('Ich erlaube ARC, während dieses Laufs meinen Standort',HTML)
  self.assertIn('Es wird für das Tracking kein Standort an einen Kartendienst gesendet.',HTML)
 def test_accessible_status_messages(self): self.assertIn('aria-live="polite"',HTML)
 def test_route_display_escapes_no_user_text_into_html(self):
  self.assertIn('function displayRoute',HTML); self.assertIn('start.label||',HTML)
if __name__=='__main__': unittest.main(verbosity=2)
