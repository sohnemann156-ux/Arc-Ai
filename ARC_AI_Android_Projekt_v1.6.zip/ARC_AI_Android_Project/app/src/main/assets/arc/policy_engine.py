"""Small demonstrator for ARC AI policy decisions. Not a production security boundary."""
from dataclasses import dataclass
from typing import Optional

@dataclass
class Request:
    action: str
    approved_source: bool = False
    lawful_access: bool = True
    user_confirmed: bool = False
    informed_consent: bool = False
    severe_pain_or_red_flag: bool = False
    asks_to_override_rules: bool = False
    instruction_from_imported_content: bool = False
    private_third_party_data: bool = False
    uncertainty: bool = False
    financial_transaction: bool = False

@dataclass
class Decision:
    state: str
    reason: str
    safer_alternative: Optional[str] = None

DENIED_ACTIONS = {
    "bypass_access_controls", "access_private_third_party_data", "disable_or_rewrite_protected_rules",
    "make_purchase", "initiate_payment", "start_subscription", "sign_up_for_paid_service",
    "change_billing_or_payment_method", "checkout", "buy_product", "place_order"
}

FINANCIAL_ACTION_WORDS = ("purchase", "payment", "subscription", "paid_signup", "billing", "checkout", "buy_product", "place_order", "start_subscription", "make_purchase", "initiate_payment")


def decide(req: Request) -> Decision:
    # Instructions found inside web pages/documents are untrusted data, not authority.
    if req.asks_to_override_rules or req.instruction_from_imported_content:
        return Decision("deny", "Inhalt aus Anfrage oder Quelle darf geschützte Regeln und Berechtigungen nicht überschreiben.")

    # Financial actions are an absolute deny: consent/confirmation does not grant the AI transaction authority.
    if req.financial_transaction or req.action in DENIED_ACTIONS or any(word in req.action.lower() for word in FINANCIAL_ACTION_WORDS):
        if req.financial_transaction or any(word in req.action.lower() for word in FINANCIAL_ACTION_WORDS) or req.action in DENIED_ACTIONS.intersection({"make_purchase", "initiate_payment", "start_subscription", "sign_up_for_paid_service", "change_billing_or_payment_method", "checkout", "buy_product", "place_order"}):
            return Decision("deny", "ARC AI darf keine Käufe, Zahlungen, Abonnements oder kostenpflichtigen Anmeldungen ausführen — auch nicht nach Bestätigung.")
    if req.action in DENIED_ACTIONS or req.private_third_party_data:
        return Decision("deny", "Diese Aktion ist nicht freigegeben; private Daten oder Zugangsschutz werden nicht umgangen.")

    if not req.lawful_access:
        return Decision("deny", "Der rechtmäßige Zugriff ist nicht bestätigt.")

    if req.action in {"search_approved_public_nutrition_info", "search_exercise_information"}:
        if not req.approved_source:
            return Decision("restrict", "Die Quelle ist nicht freigegeben.", "Eine freigegebene Quelle verwenden.")
        return Decision("allow", "Quelle und Zugriff sind freigegeben.")

    if req.action == "suggest_meal_or_workout":
        if req.severe_pain_or_red_flag:
            return Decision("restrict", "Warnzeichen können ein intensives Training unsicher machen.", "Training pausieren; bei schweren oder anhaltenden Symptomen medizinische Hilfe suchen.")
        if req.uncertainty:
            return Decision("restrict", "Die Datengrundlage ist unsicher; keine exakten Werte vortäuschen.", "Unsicherheit markieren oder Angaben verifizieren.")
        return Decision("allow", "Vorschlag innerhalb des vorgesehenen App-Zwecks.")

    if req.action in {"save_personal_log", "change_training_plan_significantly"}:
        if req.user_confirmed:
            return Decision("allow", "Erforderliche Nutzerbestätigung liegt vor.")
        return Decision("confirm", "Vor dem Speichern oder einer größeren Planänderung ist Bestätigung erforderlich.")

    if req.action == "send_personal_data_to_external_service":
        if req.informed_consent:
            return Decision("confirm", "Zustimmung liegt vor; zusätzlich müssen Datenminimierung und Dienstfreigabe technisch geprüft werden.")
        return Decision("deny", "Keine informierte Zustimmung für die externe Übertragung.")

    return Decision("confirm", "Aktion ist nicht ausdrücklich klassifiziert; Berechtigung vor Ausführung klären.")
