#!/bin/sh
set -eu
python -m unittest -v test_app.py test_policy_engine.py test_offline_run.py test_pwa.py test_profile_features.py test_recipe_preferences.py test_plan_studio.py test_ai_backend.py
