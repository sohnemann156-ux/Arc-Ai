import ast
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent

class AIBackendTests(unittest.TestCase):
    def test_api_key_is_environment_only(self):
        server = (ROOT / 'server.py').read_text()
        html = (ROOT / 'index.html').read_text()
        self.assertIn('os.environ.get("OPENAI_API_KEY"', server)
        self.assertNotIn('sk-proj-', html)
        self.assertNotIn('sk-live-', html)

    def test_endpoint_and_fallback_exist(self):
        self.assertIn('self.path != "/api/plan"', (ROOT / 'server.py').read_text())
        html = (ROOT / 'index.html').read_text()
        self.assertIn("fetch('/api/plan'", html)
        self.assertIn('Online-KI derzeit nicht erreichbar', html)

    def test_exercise_library_expanded(self):
        html = (ROOT / 'index.html').read_text()
        section = html.split('const EXERCISES=[', 1)[1].split('];', 1)[0]
        self.assertGreaterEqual(section.count("['"), 30)

if __name__ == '__main__':
    unittest.main()
