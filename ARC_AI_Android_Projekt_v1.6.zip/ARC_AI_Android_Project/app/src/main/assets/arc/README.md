# ARC AI — Gesundheit & Fitness v1.6 (Handy-Testversion)

## Leitidee
Ein ansprechender, unkomplizierter Gesundheits- und Fitnessbegleiter für Menschen, die fit bleiben oder werden möchten. Die App soll verständlich bleiben und keinen Leistungsdruck erzeugen.

## Neu in v1.4
- Ernährungsbereich mit klarerer Einleitung und opt-in Rezeptideen.
- Rezeptideen sind standardmäßig ausgeschaltet. Nutzer aktivieren sie ausdrücklich und tragen Lieblingszutaten, zu meidende Zutaten und Ernährungsweise selbst ein.
- Es gibt keine automatische Kamera-, Foto- oder Essensüberwachung. Mahlzeiten werden nicht ohne ausdrückliche Eingabe analysiert.
- Vorlieben werden lokal im Browser gespeichert.
- Der Rezept-Assistent nutzt derzeit einfache lokale Rezeptvorlagen und sortiert sie nach angegebenen Vorlieben. Eine echte generative KI und automatische Fotoerkennung sind noch nicht verbunden.
- Keine bezahlten APIs, Käufe, Zahlungen oder Abonnements.

## Bereits enthalten
Lokales Profil, Trainings- und Ernährungsprotokoll, Essensfoto-Vorschau, manuelle Lebensmittelsuche, Routensuche/GPS-Funktionen, lokale Datenexport/-import und PWA-Shell.

## Grenzen
Das Essensfoto wird lokal angezeigt und nicht hochgeladen; automatische Bilderkennung ist nicht verbunden. Der Rezept-Assistent ist ein lokaler Prototyp und keine echte KI. Kein Server-Login und keine Cloud-Synchronisierung. Kalorien- und Proteinwerte sind Näherungen und kein medizinischer Rat. Die App ersetzt keine medizinische Beratung.

## Auf dem Handy testen
ZIP entpacken und über HTTPS oder localhost öffnen. PWA-Installation, Service Worker und GPS funktionieren nicht vollständig über `file://`. Automatisierte Tests ersetzen keine Tests auf einem echten Handy.

## Tests
`./run_tests.sh`


Version 1.3 adds a local workout plan studio: character-inspired plan ideas, custom goals, and plans based on user-described video workouts. Video links are stored as references only and are not automatically watched or analyzed. Generated plans are rule-based prototypes, not medical advice.


## Trainingsstudio in Version 1.3
- Trainingspläne inspiriert von Film-/Serienfiguren, frei definierte Ziele und Video-Beschreibungen.
- Eigene Gym-Pläne lassen sich als TXT/CSV lokal importieren oder als Text einfügen und in Einheiten aufteilen.
- Lokale Beispielpläne: Zuhause, Fitnessstudio, Push/Pull/Beine, Beweglichkeit und Einsteiger-Ausdauer.
- Grenzen klar gekennzeichnet: Videolinks werden nicht automatisch analysiert; Fotos/PDFs werden noch nicht per OCR gelesen; Vorlagen sind keine verifizierten Trainingspläne realer Figuren oder Marken.


## Version 1.5 – persönlicher Trainingsplan

- Ziele auswählbar: allgemeine Fitness, Muskelaufbau, Kraft, Ausdauer, Beweglichkeit, Körpergewichts-Ziel oder Mischung.
- Einstieg mit wenig Aufwand: 10/20/30/45-Minuten-Auswahl, Trainingsgefühl und optionale Hinweise zu Einschränkungen oder Wohnsituation.
- Trainingsentwürfe passen Übungsvorschläge an Ziel, Niveau und Ausrüstung an. Der Nutzer prüft und speichert den Plan selbst; es wird kein Plan automatisch gestartet oder zugewiesen.
- Überarbeiteter Bereich „Plan erstellen“ und dezente ARC-Logo-Introanimation (mit Rücksicht auf reduzierte Animationseinstellungen).
- Transparenz: Die Planerstellung verwendet aktuell lokale Regeln und Vorlagen. Eine echte generative KI erfordert noch eine sichere Backend-Anbindung; API-Schlüssel gehören nicht in die App-Dateien.


## Version 1.6 – größere Übungsbibliothek und optionales KI-Backend

- Übungsbibliothek auf 36 Einträge erweitert: Einsteiger- und Gerätevarianten, Kraft, Ausdauer, Mobilität, Gleichgewicht und Erholung.
- Neuer optionaler `server.py`: Browser ruft `/api/plan` auf; der Server ruft die OpenAI Responses API auf. Der API-Schlüssel wird ausschließlich als Umgebungsvariable auf dem Server gesetzt, nie in die App eingebaut.
- Ohne Backend oder API-Key bleibt der lokale Plan-Generator nutzbar; die App kennzeichnet, dass Online-KI nicht verfügbar ist.
- Nutzereingaben werden erst nach Betätigung von „Meinen Plan erstellen“ an den konfigurierten KI-Dienst übermittelt. Bitte keine unnötig sensiblen Daten eingeben.

### KI lokal starten (Entwicklung)
1. Python 3 installieren.
2. Im Projektordner eine Umgebungsvariable `OPENAI_API_KEY` mit deinem API-Schlüssel setzen. Beispiel Bash: `export OPENAI_API_KEY='…'` (den Schlüssel nicht in Dateien oder Chats veröffentlichen).
3. `python server.py` ausführen und `http://127.0.0.1:8080` öffnen.
4. Für echte Nutzung außerhalb des eigenen Rechners ist HTTPS, ein abgesicherter Hosting-Anbieter, Zugriffsschutz/Rate-Limits und die Prüfung der Datenschutzanforderungen nötig. Den Server nicht ungeschützt öffentlich freigeben. API-Nutzung kann Kosten verursachen; diese hängen vom Anbieter, Modell und Verbrauch ab.

**Wichtig:** Die Online-KI kann erst arbeiten, wenn ein gültiger API-Schlüssel und Netzwerkzugriff eingerichtet sind. In dieser Umgebung wurde kein persönlicher API-Schlüssel bereitgestellt, daher konnte kein echter Anbieteraufruf durchgeführt werden.
