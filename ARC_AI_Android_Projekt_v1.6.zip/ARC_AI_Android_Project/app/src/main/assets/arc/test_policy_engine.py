import unittest
from policy_engine import Request, decide

class PolicyEngineTests(unittest.TestCase):
    def test_approved_nutrition_source_allowed(self):
        self.assertEqual(decide(Request("search_approved_public_nutrition_info", approved_source=True)).state, "allow")

    def test_unapproved_source_restricted(self):
        self.assertEqual(decide(Request("search_approved_public_nutrition_info", approved_source=False)).state, "restrict")

    def test_private_third_party_data_denied(self):
        self.assertEqual(decide(Request("access_private_third_party_data")).state, "deny")

    def test_prompt_injection_from_webpage_denied(self):
        self.assertEqual(decide(Request("search_exercise_information", approved_source=True, instruction_from_imported_content=True)).state, "deny")

    def test_rule_override_denied(self):
        self.assertEqual(decide(Request("disable_or_rewrite_protected_rules", asks_to_override_rules=True)).state, "deny")

    def test_major_plan_change_requires_confirmation(self):
        self.assertEqual(decide(Request("change_training_plan_significantly")).state, "confirm")

    def test_confirmed_plan_change_allowed(self):
        self.assertEqual(decide(Request("change_training_plan_significantly", user_confirmed=True)).state, "allow")

    def test_severe_pain_restricts_workout(self):
        result = decide(Request("suggest_meal_or_workout", severe_pain_or_red_flag=True))
        self.assertEqual(result.state, "restrict")
        self.assertIsNotNone(result.safer_alternative)

    def test_uncertain_nutrition_values_not_presented_as_certain(self):
        self.assertEqual(decide(Request("suggest_meal_or_workout", uncertainty=True)).state, "restrict")

    def test_external_transfer_without_consent_denied(self):
        self.assertEqual(decide(Request("send_personal_data_to_external_service")).state, "deny")

    def test_illegal_access_denied(self):
        self.assertEqual(decide(Request("search_exercise_information", approved_source=True, lawful_access=False)).state, "deny")

    def test_purchase_is_always_denied_even_if_confirmed(self):
        result = decide(Request("make_purchase", user_confirmed=True, informed_consent=True))
        self.assertEqual(result.state, "deny")
        self.assertIn("keine Käufe", result.reason)

    def test_payment_is_always_denied(self):
        self.assertEqual(decide(Request("initiate_payment", user_confirmed=True)).state, "deny")

    def test_subscription_is_always_denied_even_if_confirmed(self):
        self.assertEqual(decide(Request("start_subscription", user_confirmed=True)).state, "deny")

    def test_financial_transaction_flag_is_always_denied(self):
        self.assertEqual(decide(Request("unknown_action", financial_transaction=True, user_confirmed=True)).state, "deny")

    def test_unknown_action_requires_review(self):
        self.assertEqual(decide(Request("unknown_action")).state, "confirm")

if __name__ == "__main__":
    unittest.main(verbosity=2)
