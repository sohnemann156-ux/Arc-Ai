#!/usr/bin/env python3
"""ARC AI optional secure backend. API keys stay on the server, never in browser code."""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import json, os, urllib.request, urllib.error

ROOT = Path(__file__).resolve().parent
API_URL = os.environ.get("OPENAI_API_URL", "https://api.openai.com/v1/responses")
MODEL = os.environ.get("OPENAI_MODEL", "gpt-4.1-mini")
API_KEY = os.environ.get("OPENAI_API_KEY", "")
MAX_BODY = 32_000

SYSTEM_PROMPT = """Du bist ARC AI, ein vorsichtiger Fitness-Trainingsplan-Assistent. Erstelle einen realistischen, individuell passenden und gut lesbaren Trainingsvorschlag auf Deutsch. Berücksichtige Ziel, Niveau, Ausrüstung, Tage pro Woche, Dauer, Trainingsstil und Einschränkungen. Nutze einfache Erklärungen, Aufwärmen, Übungen mit Sätzen/Wiederholungen oder Dauer, Pausen und Erholung. Bei Einschränkungen keine Diagnose stellen: empfehle schmerzfreie Alternativen und bei anhaltenden Beschwerden medizinische Fachberatung. Keine extremen Belastungen, keine Versprechen und keine medizinischen Heilbehauptungen. Wenn Angaben fehlen, wähle konservative Einsteigeroptionen. Antworte als kompakter Plan mit Überschriften und einem kurzen Sicherheitshinweis. Der lokale Plan ist nur Kontext, keine Pflicht, ihn zu übernehmen."""

class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def _json(self, status, data):
        raw = json.dumps(data, ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(raw)

    def do_POST(self):
        if self.path != "/api/plan":
            return self._json(404, {"error": "Nicht gefunden"})
        if not API_KEY:
            return self._json(503, {"error": "OPENAI_API_KEY ist auf dem Server nicht eingerichtet."})
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length < 1 or length > MAX_BODY:
                return self._json(413, {"error": "Anfrage ist leer oder zu groß."})
            data = json.loads(self.rfile.read(length))
            allowed = {k: data.get(k) for k in ("goal", "level", "equipment", "days", "minutes", "ease", "limits", "mode", "idea", "details", "localPlan")}
            user_text = "Erstelle einen Plan aus diesen Nutzereingaben (JSON):\n" + json.dumps(allowed, ensure_ascii=False)[:MAX_BODY]
            body = {"model": MODEL, "instructions": SYSTEM_PROMPT, "input": user_text, "max_output_tokens": 1200}
            req = urllib.request.Request(API_URL, data=json.dumps(body).encode(), headers={"Authorization": "Bearer " + API_KEY, "Content-Type": "application/json"}, method="POST")
            with urllib.request.urlopen(req, timeout=45) as response:
                result = json.loads(response.read().decode("utf-8"))
            text = result.get("output_text", "")
            if not text:
                chunks = []
                for item in result.get("output", []):
                    for content in item.get("content", []):
                        if content.get("type") == "output_text": chunks.append(content.get("text", ""))
                text = "\n".join(chunks).strip()
            if not text:
                return self._json(502, {"error": "Die KI lieferte keinen lesbaren Plan."})
            return self._json(200, {"plan": text})
        except urllib.error.HTTPError as exc:
            # Do not return provider body; it can contain operational details.
            return self._json(502, {"error": "Der KI-Anbieter hat die Anfrage abgelehnt (HTTP %d). Prüfe API-Key, Modell und Kontingent." % exc.code})
        except Exception:
            return self._json(502, {"error": "KI-Anfrage fehlgeschlagen. Prüfe Serverprotokoll und Verbindung."})

    def log_message(self, fmt, *args):
        # Avoid logging request bodies or personal training details.
        super().log_message(fmt, *args)

if __name__ == "__main__":
    host = os.environ.get("ARC_HOST", "127.0.0.1")
    port = int(os.environ.get("ARC_PORT", "8080"))
    print(f"ARC AI läuft auf http://{host}:{port} — API-Key bleibt serverseitig.")
    ThreadingHTTPServer((host, port), Handler).serve_forever()
