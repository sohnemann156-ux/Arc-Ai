import unittest
from pathlib import Path
ROOT=Path(__file__).parent
HTML=(ROOT/'index.html').read_text(encoding='utf-8')
class OfflineRunTests(unittest.TestCase):
 def test_offline_controls_exist(self):
  for token in ('cacheOfflineRoute','startOfflineRun','stopOfflineRun','savedOfflineRoute','offlineElapsed','offlineDistance','offlineCue'): self.assertIn(token,HTML)
 def test_route_geometry_is_saved_locally(self):
  self.assertIn('geometry:{coordinates:coords}',HTML); self.assertIn('state.routes.push(rec)',HTML)
 def test_simulation_uses_prior_pace_and_elapsed_time(self):
  self.assertIn('sec/60/offlineRun.paceMinKm',HTML); self.assertIn('tickOfflineRun',HTML)
 def test_simulated_distance_is_labelled_as_estimate(self):
  self.assertIn('Zeit-/Tempo-Schätzung',HTML); self.assertIn('Distanz geschätzt, nicht GPS-gemessen',HTML)
 def test_saved_routes_survive_in_local_state(self):
  self.assertIn('renderOfflineRoutes()',HTML); self.assertIn('localStorage.setItem(KEY',HTML)
 def test_offline_run_logs_without_claiming_gps(self):
  self.assertIn('simulated:!hasGps',HTML); self.assertIn('gps:hasGps',HTML)
 def test_financial_safety_rule_remains(self): self.assertIn('Ich darf niemals etwas kaufen oder bestellen',HTML)
 def test_no_external_script_dependency(self): self.assertNotRegex(HTML,r'<script[^>]+src=')
if __name__=='__main__': unittest.main(verbosity=2)
