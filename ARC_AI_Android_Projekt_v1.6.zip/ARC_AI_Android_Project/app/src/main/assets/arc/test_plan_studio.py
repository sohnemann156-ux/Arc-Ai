import pathlib
import unittest

ROOT = pathlib.Path(__file__).parent
HTML = (ROOT / 'index.html').read_text(encoding='utf-8')

class PlanStudioTests(unittest.TestCase):
    def test_multiple_plan_sources_are_available(self):
        for value in ['character', 'custom', 'video', 'gym', 'library']:
            self.assertIn(f'value="{value}"', HTML)

    def test_local_gym_text_import_is_available(self):
        self.assertIn('id="planImportFile"', HTML)
        self.assertIn('accept=".txt,.csv,text/plain,text/csv"', HTML)
        self.assertIn("const txt=await f.text()", HTML)
        self.assertIn('Videolinks werden nicht automatisch angesehen', HTML)

    def test_example_programs_are_included(self):
        for key in ['home:', 'gym:', 'ppl:', 'mobility:', 'cardio:']:
            self.assertIn(key, HTML)

    def test_personal_goal_and_low_friction_options_exist(self):
        for value in ['health', 'muscle', 'strength', 'endurance', 'mobility', 'weight', 'mixed']:
            self.assertIn(f'value=\"{value}\"', HTML)
        self.assertIn('id=\"planEase\"', HTML)
        self.assertIn('id=\"planMinutes\"', HTML)
        self.assertIn('id=\"planLimits\"', HTML)
        self.assertIn('arc-intro-mark', HTML)

    def test_plan_stays_local_and_can_be_saved(self):
        self.assertIn('state.settings.customTrainingPlan=currentPlan', HTML)
        self.assertIn('wurde lokal auf diesem Gerät gespeichert', HTML)

    def test_import_size_is_limited(self):
        self.assertIn('f.size>1024*1024', HTML)
        self.assertIn('Ein Foto oder PDF muss in dieser Version noch manuell abgeschrieben werden', HTML)

if __name__ == '__main__':
    unittest.main()
