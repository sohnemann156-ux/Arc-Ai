import pathlib
import unittest

ROOT = pathlib.Path(__file__).parent
HTML = (ROOT / 'index.html').read_text(encoding='utf-8')

class RecipePreferenceTests(unittest.TestCase):
    def test_recipe_assistant_is_opt_in(self):
        self.assertIn('id="recipeAssistantEnabled" type="checkbox"', HTML)
        self.assertIn("toggle.checked=!!pref.enabled", HTML)

    def test_preferences_are_user_provided_and_local(self):
        self.assertIn('id="foodLikes"', HTML)
        self.assertIn('id="foodAvoid"', HTML)
        self.assertIn('id="foodStyle"', HTML)
        self.assertIn('state.settings.foodPreferences', HTML)
        self.assertIn('Keine Kamera im Hintergrund und keine automatische Essensüberwachung.', HTML)

    def test_no_claim_of_real_ai_or_photo_recognition(self):
        self.assertIn('Eine echte generative KI ist noch nicht verbunden.', HTML)
        self.assertIn('automatische KI-Bilderkennung ist noch nicht verbunden.', HTML)

if __name__ == '__main__':
    unittest.main()
