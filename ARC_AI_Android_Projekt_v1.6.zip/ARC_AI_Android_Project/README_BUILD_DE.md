# ARC AI v1.6 – Android-Projekt

Dieses Projekt verpackt die vorhandene ARC-AI-Web-App in eine einfache Android-App (WebView). Es enthält die Web-App-Dateien und einen GitHub-Actions-Buildablauf.

## APK erzeugen

**Mit Android Studio:**
1. Android Studio auf einem Computer installieren.
2. Diesen Ordner als Projekt öffnen und die Gradle-Synchronisierung abwarten.
3. `Build > Build Bundle(s) / APK(s) > Build APK(s)` auswählen.
4. Die Debug-APK liegt üblicherweise in `app/build/outputs/apk/debug/app-debug.apk`.

**Mit GitHub Actions:**
1. Ein privates GitHub-Repository erstellen und den Inhalt dieses Projektordners hochladen.
2. Den Workflow `Build ARC AI APK` unter Actions manuell starten.
3. Nach erfolgreichem Lauf das Artefakt `ARC-AI-debug-APK` herunterladen.

## Vor Installation beachten

- Dieses ZIP ist ein Quellprojekt, keine bereits kompilierte APK.
- Paketkennung `de.lunarum.arcai` ist ein vorläufiger Wert. Für ein Update über eine bestehende Android-Installation müssen Paketkennung und Signaturschlüssel exakt zur bisherigen App passen. Diese Informationen sind derzeit nicht bekannt.
- Eine Debug-APK ist zum Testen gedacht, nicht für eine spätere Veröffentlichung.
- Viele App-Daten können lokal in der bisherigen Browser-/PWA-Version gespeichert sein. Vor einem Wechsel bitte die bisherige App nicht löschen und vorhandene Export-/Backup-Funktionen nutzen.
- Die vorbereitete Online-KI benötigt ein separat sicher gehostetes Backend. API-Schlüssel dürfen nicht in die App eingebaut werden.
